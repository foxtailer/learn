from django.contrib import admin
from explore.models import Wisdom
# Register your models here.

admin.site.register(Wisdom)