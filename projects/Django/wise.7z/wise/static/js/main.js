addEventListener("wheel", (event) => {
  console.log("gg")
});